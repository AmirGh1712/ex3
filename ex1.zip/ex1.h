
#ifndef EX1_H
#define EX1_H

#include "Value.h"
#include "Variable.h"
#include "Plus.h"
#include "Minus.h"
#include "Mul.h"
#include "Div.h"
#include "UPlus.h"
#include "UMinus.h"
#include "Interpreter.h"

#endif //EX1_H
