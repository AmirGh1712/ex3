#include "UPlus.h"
double UPlus :: calculate() {
    return this->e->calculate();
}