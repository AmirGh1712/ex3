//
// Created by amir on 01/01/2020.
//

#include "Variable.h"
