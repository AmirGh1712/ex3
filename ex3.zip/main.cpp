#include <iostream>
#include <map>
#include "Command.h"
#include "PrintCommand.h"
#include "Parser.h"
#include "OpenServerCommand.h"
#include "ConnectCommand.h"
#include "VarCommand.h"

int main() {
    string a[9] = {"Print", "\"hello world\"","openDataServer", "5400", "connectControlClient",
                   "5402", "\"127.0.0.1\"", "Print", "\"done\""};
   // string a[] = {"var", "a", "->", "sim", "s/gds/rgsdz"};
    PrintCommand* p = new PrintCommand();
    OpenServerCommand* os = new OpenServerCommand();
    ConnectCommand* c = new ConnectCommand();
    VarCommand* v = new VarCommand();
    map<string, Command*> map;
    map["Print"] = p;
    map["openDataServer"] = os;
    map["connectControlClient"] = c;
    map["var"] = v;
    parser(a, 5, map);
    os->join();
    return 0;
}